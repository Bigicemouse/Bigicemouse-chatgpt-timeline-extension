(function(root) {
  const ns = root.TLTimelineModules = root.TLTimelineModules || {};
  const utils = ns.utils;
  const stateModule = ns.state;
  const auth = ns.auth;
  const api = ns.conversationApi;
  const dom = ns.domCollector;
  const locator = ns.locator;
  const timeline = ns.timeline;
  const layout = ns.layout;
  const geometry = ns.geometry;
  const virtualList = ns.virtualList;
  const formulaCopy = ns.formulaCopy;
  const CONSTANTS = utils.CONSTANTS;
  const CONVERSATION_OBSERVER_CONFIG = {
    childList: true,
    subtree: true,
    characterData: true,
    attributes: true,
    attributeFilter: ['aria-label', 'data-testid']
  };
  const REFRESH_DEBOUNCE_MS = 220;
  const STREAMING_REFRESH_DEBOUNCE_MS = 1000;
  const hasDom = !!(root && root.document && root.location);
  const state = stateModule.createState();

  function clearTimers() {
    ['refreshTimer', 'apiRefreshTimer', 'locateTimer', 'highlightTimer'].forEach(function(key) {
      if (state[key]) root.clearTimeout(state[key]);
      state[key] = null;
    });
    cancelFrame(state, 'scrollFrame');
    cancelFrame(state, 'resizeFrame');
  }

  function requestFrame(callback) {
    if (root.requestAnimationFrame) return root.requestAnimationFrame(callback);
    return root.setTimeout(callback, 16);
  }

  function cancelFrame(targetState, key) {
    if (!targetState || !targetState[key]) return;
    if (root.cancelAnimationFrame) {
      root.cancelAnimationFrame(targetState[key]);
    } else {
      root.clearTimeout(targetState[key]);
    }
    targetState[key] = null;
  }

  function disconnectRuntime() {
    if (state.observer) {
      state.observer.disconnect();
      state.observer = null;
    }
    if (state.scrollEl && state.scrollHandler) {
      state.scrollEl.removeEventListener('scroll', state.scrollHandler);
    }
    state.scrollEl = null;
    state.scrollHandler = null;
    clearTimers();
  }

  function stopBootstrapObserver() {
    if (state.bootstrapObserver) {
      state.bootstrapObserver.disconnect();
      state.bootstrapObserver = null;
    }
  }

  function startBootstrapObserver() {
    if (state.bootstrapObserver || !root.MutationObserver || !root.document.body) return;
    state.bootstrapObserver = new MutationObserver(function() {
      if (utils.shouldInitializeConversation(root.location && root.location.href, dom.collectTurnSections().length > 0)) {
        handleRouteChange(false);
      }
    });
    state.bootstrapObserver.observe(root.document.body, { childList: true, subtree: true });
  }

  function destroy() {
    disconnectRuntime();
    timeline.destroyUI(state);
    stateModule.resetConversation(state, '');
    state.initialized = false;
    state.lastUrl = root.location && root.location.href || '';
  }

  function isRouteCurrent(targetState, routeToken, conversationId) {
    return !!(targetState &&
      targetState.routeToken === routeToken &&
      targetState.conversationId === conversationId);
  }

  function applyTurns(sourceTurns, force) {
    const nextTurns = utils.mergeTurnsById([], sourceTurns);
    const signature = utils.buildConversationSignature(nextTurns);
    const sameElements = nextTurns.length === state.turns.length && nextTurns.every(function(turn, index) {
      return turn.el === state.turns[index].el;
    });
    if (!force && signature === state.lastSignature && sameElements) return false;

    state.turns = nextTurns;
    state.groups = utils.buildQaGroups(nextTurns);
    state.lastSignature = signature;
    state.anchorGeometryCache = null;
    state.activeGroupId = locator.computeActiveGroupId(state) || state.activeGroupId || (state.groups[0] && state.groups[0].id) || '';
    timeline.render(state, actions);
    return true;
  }

  function refreshFromDom(force, routeToken, conversationId) {
    if (routeToken && !isRouteCurrent(state, routeToken, conversationId)) return false;
    bindScrollSpy();
    if (!state.domCollectionReady) {
      if (state.apiTurns.length || force) return applyTurns(state.apiTurns, !!force);
      return false;
    }
    state.domTurns = dom.collectTurns();
    state.domTurnCache = dom.cacheDomTurns(state.domTurnCache, state.domTurns);
    const cachedDomTurns = dom.attachDomElementsToTurns(state.domTurnCache, state.domTurns);
    const cachedById = new Map(cachedDomTurns.map(function(turn) { return [turn.id, turn]; }));
    const attachedApi = dom.attachDomElementsToTurns(state.apiTurns, cachedDomTurns).map(function(turn) {
      const current = turn.seenInCurrentDom && cachedById.get(turn.domTurnId);
      return current ? Object.assign({}, turn, {
        text: current.text,
        summary: current.summary,
        searchText: current.searchText
      }) : turn;
    });
    const matchedDomIds = new Set(attachedApi.filter(function(turn) { return turn.seenInCurrentDom; }).map(function(turn) { return turn.domTurnId; }));
    const mergedSource = state.apiTurns.length ? utils.mergeTurnsById(attachedApi, cachedDomTurns.filter(function(turn) {
      return !matchedDomIds.has(turn.id);
    })) : cachedDomTurns;
    const sourceTurns = mergedSource;
    if (sourceTurns.length || force) return applyTurns(sourceTurns, !!force);
    return false;
  }

  function shouldFetchConversation(targetState, now) {
    const currentTime = Number(now) || 0;
    if (!targetState.conversationId || targetState.conversationId.indexOf('dom:') === 0 || targetState.loading) return false;
    if (targetState.apiRefreshAttempts >= CONSTANTS.API_REFRESH_MAX_ATTEMPTS) return false;
    if (!targetState.apiTurns.length) return true;
    return currentTime - (targetState.lastApiFetchAt || 0) >= CONSTANTS.API_REFRESH_RETRY_MS;
  }

  function scheduleApiRefresh(routeToken, conversationId) {
    const token = routeToken || state.routeToken;
    const id = conversationId || state.conversationId;
    if (state.apiRefreshTimer || !isRouteCurrent(state, token, id) || !shouldFetchConversation(state, Date.now() + CONSTANTS.API_REFRESH_RETRY_MS)) return;
    state.apiRefreshTimer = root.setTimeout(function() {
      state.apiRefreshTimer = null;
      if (isRouteCurrent(state, token, id)) fetchConversation(token, id);
    }, CONSTANTS.API_REFRESH_RETRY_MS);
  }

  function fetchConversation(routeToken, conversationId) {
    const token = routeToken || state.routeToken;
    const id = conversationId || state.conversationId;
    if (!isRouteCurrent(state, token, id)) return;
    if (!shouldFetchConversation(state, Date.now())) return;
    if (state.apiRefreshTimer) {
      root.clearTimeout(state.apiRefreshTimer);
      state.apiRefreshTimer = null;
    }
    state.loading = !state.apiTurns.length;
    state.error = '';
    state.lastApiFetchAt = Date.now();
    state.apiRefreshAttempts += 1;
    if (state.loading) timeline.render(state, actions);

    api.fetchConversationJson(id).then(function(data) {
      if (!isRouteCurrent(state, token, id)) return;
      state.loading = false;
      const apiResult = api.collectTurnsWithMetadata
        ? api.collectTurnsWithMetadata(data)
        : { turns: api.collectTurnsFromConversationData(data), metadata: null };
      const nextApiTurns = apiResult.turns || [];
      state.apiCompleteness = apiResult.metadata || null;
      if (!nextApiTurns.length) {
        state.error = 'Conversation API returned no readable turns.';
        refreshFromDom(true, token, id);
        scheduleApiRefresh(token, id);
        return;
      }
      state.apiTurns = nextApiTurns;
      refreshFromDom(true, token, id);
      scheduleApiRefresh(token, id);
    }).catch(function(error) {
      if (!isRouteCurrent(state, token, id)) return;
      state.loading = false;
      state.error = String(error && error.message ? error.message : error || 'Conversation API failed.');
      state.apiCompleteness = {
        pathTurnCount: 0,
        allReadableMappingTurnCount: 0,
        usedFallback: false,
        apiCompleteLikely: false,
        reason: 'api-error'
      };
      refreshFromDom(true, token, id);
      scheduleApiRefresh(token, id);
    });
  }

  function scheduleRefresh(force, routeToken, conversationId, delayMs) {
    const token = routeToken || state.routeToken;
    const id = conversationId || state.conversationId;
    const delay = Math.max(0, Number(delayMs) || REFRESH_DEBOUNCE_MS);
    if (!isRouteCurrent(state, token, id)) return;
    if (state.refreshTimer) {
      if (!force) return;
      root.clearTimeout(state.refreshTimer);
    }
    state.refreshTimer = root.setTimeout(function() {
      state.refreshTimer = null;
      if (isRouteCurrent(state, token, id)) refreshFromDom(!!force, token, id);
    }, delay);
  }

  function isAssistantStreaming() {
    return !!(utils.qs('[data-testid="stop-button"]') ||
      utils.qs('button[aria-label*="停止"]') ||
      utils.qs('button[aria-label*="Stop"]'));
  }

  function getConversationObserverConfig() {
    return Object.assign({}, CONVERSATION_OBSERVER_CONFIG);
  }

  function isTimelineNode(node) {
    if (!node || node.nodeType !== 1) return false;
    if (node.id === CONSTANTS.PANEL_ID || node.id === CONSTANTS.STYLE_ID) return true;
    return !!(node.closest && node.closest('#' + CONSTANTS.PANEL_ID));
  }

  function mutationBelongsToTimeline(mutation) {
    if (!mutation) return false;
    if (isTimelineNode(mutation.target)) return true;
    const added = Array.prototype.slice.call(mutation.addedNodes || []);
    const removed = Array.prototype.slice.call(mutation.removedNodes || []);
    const touched = added.concat(removed);
    return touched.length > 0 && touched.every(isTimelineNode);
  }

  function shouldIgnoreMutationBatch(mutations) {
    const list = Array.prototype.slice.call(mutations || []);
    return list.length > 0 && list.every(mutationBelongsToTimeline);
  }

  function observeConversation() {
    if (state.observer || !root.MutationObserver || !root.document.body) return;
    // The app retains hidden routes and can replace the active scroll root.
    const target = root.document.body;
    state.observer = new MutationObserver(function(mutations) {
      if (shouldIgnoreMutationBatch(mutations)) return;
      if (mutations.some(function(mutation) { return mutation.type !== 'characterData' && !mutationBelongsToTimeline(mutation); })) {
        state.ui.existingTimelineCandidates = null;
      }
      if (root.location && root.location.href !== state.lastUrl) {
        handleRouteChange(false);
        return;
      }
      // Do not force layout inside a MutationObserver callback while React is
      // mounting a long answer. Resolve the visible root in the throttled refresh.
      const conversationRoot = state.scrollEl || root.document;
      const changedRoot = !state.scrollEl || !state.scrollEl.isConnected;
      const relevant = mutations.filter(function(mutation) {
        return !mutationBelongsToTimeline(mutation) && mutation.type !== 'attributes' &&
          (conversationRoot === root.document || conversationRoot.contains(mutation.target));
      });
      if (!changedRoot && !relevant.length) return;
      dom.invalidateTextCache(relevant);
      state.anchorGeometryCache = null;
      state.domCollectionReady = true;
      scheduleRefresh(
        false,
        state.routeToken,
        state.conversationId,
        isAssistantStreaming() ? STREAMING_REFRESH_DEBOUNCE_MS : REFRESH_DEBOUNCE_MS
      );
    });
    state.observer.observe(target, CONVERSATION_OBSERVER_CONFIG);
  }

  function bindScrollSpy() {
    const targetState = arguments.length > 0 && arguments[0] ? arguments[0] : state;
    const explicitScrollEl = arguments.length > 1 ? arguments[1] : null;
    const nextScrollEl = explicitScrollEl || locator.findScrollTarget();
    if (!nextScrollEl || targetState.scrollEl === nextScrollEl) return;
    if (targetState.scrollEl && targetState.scrollHandler) {
      targetState.scrollEl.removeEventListener('scroll', targetState.scrollHandler);
    }
    cancelFrame(targetState, 'scrollFrame');
    targetState.anchorGeometryCache = null;
    targetState.scrollEl = nextScrollEl;
    targetState.scrollHandler = function() {
      scheduleScrollSpyUpdate(targetState);
    };
    targetState.scrollEl.addEventListener('scroll', targetState.scrollHandler, { passive: true });
  }

  function scheduleScrollSpyUpdate(targetState) {
    if (!targetState || targetState.scrollFrame) return;
    targetState.scrollFrame = requestFrame(function() {
      targetState.scrollFrame = null;
      updateActiveGroupFromScroll(targetState);
    });
  }

  function updateActiveGroupFromScroll(targetState) {
    const nextActive = locator.computeActiveGroupId(targetState);
    if (nextActive && nextActive !== targetState.activeGroupId) {
      targetState.activeGroupId = nextActive;
      timeline.updateActiveClasses(targetState);
    }
  }

  function scheduleResizeRefresh() {
    if (state.resizeFrame) return;
    state.resizeFrame = requestFrame(function() {
      state.resizeFrame = null;
      if (!state.initialized) return;
      state.anchorGeometryCache = null;
      if (layout) layout.applyLayout(state);
      timeline.render(state, actions);
    });
  }

  function initConversation(conversationId) {
    stopBootstrapObserver();
    if (state.initialized && state.conversationId === conversationId) {
      scheduleRefresh(false, state.routeToken, conversationId);
      fetchConversation(state.routeToken, conversationId);
      return;
    }

    disconnectRuntime();
    stateModule.resetConversation(state, conversationId);
    const routeToken = state.routeToken;
    state.initialized = true;
    state.domCollectionReady = true;
    state.lastUrl = root.location.href;
    timeline.ensureUI(state, actions);
    if (layout) layout.applyLayout(state);
    timeline.render(state, actions);
    bindScrollSpy();
    observeConversation();
    if (conversationId.indexOf('dom:') === 0) {
      scheduleRefresh(true, routeToken, conversationId);
    } else {
      fetchConversation(routeToken, conversationId);
    }
  }

  function handleRouteChange(force) {
    const url = root.location && root.location.href;
    const conversationId = utils.getConversationIdFromUrl(url);
    const hasConversationTurns = conversationId ? false : dom.collectTurnSections().length > 0;

    if (!utils.shouldInitializeConversation(url, hasConversationTurns)) {
      if (state.initialized || force) destroy();
      state.lastUrl = url || '';
      startBootstrapObserver();
      return;
    }
    initConversation(conversationId || ('dom:' + url));
  }

  function hookHistory() {
    if (root.__tlTimelineHistoryHooked__) return;
    root.__tlTimelineHistoryHooked__ = true;
    const rawPushState = root.history.pushState;
    const rawReplaceState = root.history.replaceState;

    root.history.pushState = function() {
      rawPushState.apply(this, arguments);
      root.setTimeout(function() { handleRouteChange(false); }, 80);
    };
    root.history.replaceState = function() {
      rawReplaceState.apply(this, arguments);
      root.setTimeout(function() { handleRouteChange(false); }, 80);
    };
    root.addEventListener('popstate', function() { handleRouteChange(false); });
    root.addEventListener('resize', function() {
      if (state.initialized) scheduleResizeRefresh();
    }, { passive: true });
    if (!state.urlCheckTimer) {
      state.urlCheckTimer = root.setInterval(function() {
        if (root.location && root.location.href !== state.lastUrl) handleRouteChange(false);
        if (!state.initialized) return;
        // React hydration may replace the page subtree after document_idle.
        if (!state.ui.panel || !state.ui.panel.isConnected) {
          if (state.observer) state.observer.disconnect();
          state.observer = null;
          timeline.ensureUI(state, actions);
          if (layout) layout.applyLayout(state);
          observeConversation();
          refreshFromDom(true, state.routeToken, state.conversationId);
        }
        timeline.syncVisibility(state);
      }, CONSTANTS.ROUTE_POLL_MS);
    }
  }

  const actions = {
    jumpToGroup: function(group) {
      if (!group || !group.anchorTurn) return;
      state.activeGroupId = group.id;
      timeline.updateActiveClasses(state);
      locator.jumpToTurn(state, group.anchorTurn);
    }
  };

  function savePopupSettings(settings) {
    if (!root.chrome || !root.chrome.storage || !root.chrome.storage.local || !root.chrome.storage.local.set) return;
    try {
      root.chrome.storage.local.set(settings);
    } catch (error) {
      // Ignore extension storage failures; local page prefs still apply.
    }
  }

  function getPluginSettings() {
    if (!state.prefs) state.prefs = stateModule.getDefaultPrefs();
    return {
      readingWidthEnabled: stateModule.normalizeBoolean(state.prefs.readingWidthEnabled, true),
      readingWidthPx: stateModule.normalizeReadingWidth(state.prefs.readingWidthPx),
      formulaCopyEnabled: stateModule.normalizeBoolean(state.prefs.formulaCopyEnabled, true)
    };
  }

  function applyFormulaCopyEnabled(enabled) {
    const nextEnabled = stateModule.normalizeBoolean(enabled, true);
    state.prefs.formulaCopyEnabled = nextEnabled;
    if (formulaCopy && formulaCopy.setEnabled) formulaCopy.setEnabled(nextEnabled);
    stateModule.savePrefs(state);
    savePopupSettings({ tlFormulaCopyEnabled: nextEnabled });
    return nextEnabled;
  }

  function applyReadingWidthEnabled(enabled) {
    const nextEnabled = stateModule.normalizeBoolean(enabled, true);
    state.prefs.readingWidthEnabled = nextEnabled;
    stateModule.savePrefs(state);
    if (layout) layout.applyLayout(state);
    savePopupSettings({ tlReadingWidthEnabled: nextEnabled });
    return nextEnabled;
  }

  function applyReadingWidthPx(widthPx) {
    const nextWidth = stateModule.normalizeReadingWidth(widthPx);
    state.prefs.readingWidthPx = nextWidth;
    stateModule.savePrefs(state);
    if (layout) layout.applyLayout(state);
    savePopupSettings({ tlReadingWidthPx: nextWidth });
    return nextWidth;
  }

  function handleRuntimeMessage(message, sender, sendResponse) {
    if (!message || !message.type) return false;
    if (message.type === 'tl-get-plugin-settings') {
      if (sendResponse) sendResponse(Object.assign({ ok: true }, getPluginSettings()));
      return true;
    }
    if (message.type === 'tl-set-reading-width') {
      const readingWidthPx = applyReadingWidthPx(message.readingWidthPx);
      if (sendResponse) sendResponse(Object.assign({ ok: true }, getPluginSettings(), { readingWidthPx: readingWidthPx }));
      return true;
    }
    if (message.type === 'tl-set-reading-width-enabled') {
      const readingWidthEnabled = applyReadingWidthEnabled(message.enabled);
      if (sendResponse) sendResponse(Object.assign({ ok: true }, getPluginSettings(), { readingWidthEnabled: readingWidthEnabled }));
      return true;
    }
    if (message.type === 'tl-set-formula-copy-enabled') {
      const formulaCopyEnabled = applyFormulaCopyEnabled(message.enabled);
      if (sendResponse) sendResponse(Object.assign({ ok: true }, getPluginSettings(), { formulaCopyEnabled: formulaCopyEnabled }));
      return true;
    }
    return false;
  }

  const testApi = {
    hasExistingTimeline: timeline.hasExistingTimeline,
    syncTimelineVisibility: timeline.syncVisibility,
    normalizeText: utils.normalizeText,
    truncate: utils.truncate,
    isConversationPage: utils.isConversationPage,
    shouldInitializeConversation: utils.shouldInitializeConversation,
    getConversationIdFromUrl: utils.getConversationIdFromUrl,
    getConversationApiUrls: utils.getConversationApiUrls,
    buildQaGroups: utils.buildQaGroups,
    buildRailTimelineItems: utils.buildRailTimelineItems,
    mergeTurnsById: utils.mergeTurnsById,
    buildConversationSignature: utils.buildConversationSignature,
    shouldFetchConversation: shouldFetchConversation,
    isRouteCurrent: isRouteCurrent,
    buildAuthHeaders: auth && auth.buildAuthHeaders,
    clearAuthCache: auth && auth.clearAuthCache,
    collectTurnsFromConversationData: api.collectTurnsFromConversationData,
    collectTurnsWithMetadata: api.collectTurnsWithMetadata,
    fetchConversationJson: api.fetchConversationJson,
    collectTurnSections: dom.collectTurnSections,
    collectTurnsFromSections: dom.collectTurnsFromSections,
    cacheDomTurns: dom.cacheDomTurns,
    attachDomElementsToTurns: dom.attachDomElementsToTurns,
    buildTimelineGeometry: geometry && geometry.buildTimelineGeometry,
    computeVirtualWindow: virtualList && virtualList.computeVirtualWindow,
    jumpToTurn: locator.jumpToTurn,
    findScrollTarget: locator.findScrollTarget,
    getCollapsedItems: timeline.getCollapsedItems,
    renderTimeline: timeline.render,
    setTimelineMode: timeline.setMode,
    getTimelineStatusText: timeline.getTimelineStatusText,
    createState: stateModule.createState,
    resetConversation: stateModule.resetConversation,
    applyLayout: layout && layout.applyLayout,
    clearLayout: layout && layout.clearLayout,
    bindScrollSpy: bindScrollSpy,
    getConversationObserverConfig: getConversationObserverConfig,
    shouldIgnoreMutationBatch: shouldIgnoreMutationBatch,
    getDefaultPrefs: stateModule.getDefaultPrefs,
    normalizeReadingWidth: stateModule.normalizeReadingWidth,
    savePrefs: stateModule.savePrefs,
    handleRuntimeMessage: handleRuntimeMessage,
    getPluginSettings: getPluginSettings,
    applyReadingWidthEnabled: applyReadingWidthEnabled,
    applyReadingWidthPx: applyReadingWidthPx,
    applyFormulaCopyEnabled: applyFormulaCopyEnabled,
    formulaCopy: formulaCopy
  };

  root.__TL_TEST_API__ = testApi;
  ns.app = {
    state: state,
    initConversation: initConversation,
    destroy: destroy,
    handleRouteChange: handleRouteChange,
    refreshFromDom: refreshFromDom,
    fetchConversation: fetchConversation
  };

  if (!hasDom || !root.location.hostname.includes('chatgpt.com')) return;
  if (root.chrome && root.chrome.runtime && root.chrome.runtime.onMessage && root.chrome.runtime.onMessage.addListener) {
    root.chrome.runtime.onMessage.addListener(handleRuntimeMessage);
  }
  if (formulaCopy && formulaCopy.setEnabled) formulaCopy.setEnabled(getPluginSettings().formulaCopyEnabled);
  if (formulaCopy && formulaCopy.initialize) formulaCopy.initialize();
  hookHistory();
  if (root.document.readyState === 'loading') {
    root.document.addEventListener('DOMContentLoaded', function() { handleRouteChange(true); });
  } else {
    handleRouteChange(true);
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);
